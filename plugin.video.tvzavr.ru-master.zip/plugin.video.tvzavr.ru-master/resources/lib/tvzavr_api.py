﻿# -*- coding: utf-8 -*-
# Module: tvzavr_api
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import urlparse
import re
import xbmc
import xbmcgui
import requests
import m3u8
import math
import random
import hashlib
import posixpath

def show_error(error_title, error_text):
    xbmcgui.Dialog().notification(error_title, error_text)

class tvzavr:

    def __init__( self, params ):

        self.debug = params.get('debug', False)
        del params['debug']

        self.addon = params.get('addon')
        self.addon_id = params.get('addon_id')
        del params['addon']
        del params['addon_id']

        self.settings = {}
        self.settings.update(params)


        base_url = 'http://api.tvzavr.ru/api'

        user_agent_dalvik = 'Dalvik/2.1.0 (Linux; U; Android 5.1)'
        user_agent_tvzplayer = 'TZPlayer/3.5.12 (Linux;Android 5.1) ExoPlayerLib/1.5.8'
        user_agent_default = 'okhttp/3.2.0'

        self.action_path = {}
        self.action_path['favorites']      = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/user/favorites'}
        self.action_path['paid']           = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/catalog/paid_videos'}
        self.action_path['catalog']        = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/catalog/get'}
        self.action_path['search']         = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/search/split'}
        self.action_path['get_seasons']    = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/video/get_seasons'}
        self.action_path['get_series']     = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/video/get_series'}
        self.action_path['get_video_url']  = {type: 'get', 'user_agent': user_agent_default, 'url': base_url + '/3.0/video/url'}
        self.action_path['get_video_info'] = {type: 'get', 'user_agent': user_agent_default, 'url': base_url + '/3.0/video/get_info'}
        self.action_path['login']          = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/user/login'}
        self.action_path['logout']         = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/user/logout'}
        self.action_path['wallet']         = {type: 'post', 'user_agent': user_agent_dalvik, 'url': base_url + '/3.0/payment/wallet_status'}

    def get_setting( self, id, default='' ):
        return self.settings.get(id, default)

    def make_request( self, action, u_params = None, r_params=None ):
        action_settings = self.action_path.get(action, '')

        url = action_settings['url']
        cookies = {'userid': self.get_setting('userid', 'null'), 'vlog-ssid': self.get_setting('vlog-ssid', 'null')}
        headers = {'User-Agent': action_settings.get('user_agent')}


        request_type = action_settings.get('type', 'post')
        if request_type == 'post':
            r = requests.post(url, data=r_params, params=u_params, headers=headers, cookies=cookies)
        elif request_type == 'get':
            r = requests.get(url, data=r_params, params=u_params, headers=headers, cookies=cookies)
        else:
            return None

        if self.debug: xbmc.log( '[%s]: url - %s ' % (self.addon_id, r.url), 3 )

        try:
            r.raise_for_status()
            result = r.json()
        except requests.exceptions.RequestException as err:
            show_error('Error', str(err))
            return None

        if action == 'login' or action == 'logout':
            result['cookie_values'] = r.cookies

        return result

    def get_video_list( self, response, action ):
        video_list = []

        if action == 'search':
            listed_video = []
            for group_list in response['search_split_list']['search_group_list']:
                for video in group_list['video_list']:
                    if video['clip__id'] not in listed_video:
                        listed_video.append(video['clip__id'])
                        video_list.append(self.get_video_data(video))
        else:
            list_key = action if action not in ['catalog', 'favorites', 'paid'] else 'video_list'
            result = response['result']
            for video in result[list_key]:
                video_list.append(self.get_video_data(video))

        return video_list

    def get_video_data( self, video ):
        info = {}

        title = ''
        title_atl = ''
        #title
        if video['clip__type_id'] == 1: #movie
            clip_id = video['clip__id']
            parent_id = video['clip__id']

            label = video['clip__name']
            title = video['clip__name']

            info['originaltitle'] = video['clip__special_name'] if video['clip__special_name'] != '' else video['clip__name']
        if video['clip__type_id'] == 2: #series
            clip_id = video['clip__id']
            parent_id = video['clip__id']

            label = video['clip__name']
            title = video['clip__name']

            info['originaltitle'] = video['clip__special_name'] if video['clip__special_name'] != '' else video['clip__name']
        elif video['clip__type_id'] == 3: #episode
            clip_id = video['clip__id']

            parent_id = video['clip__parent_node_id']
            parent_info = self.get_video_info(parent_id)['video_data']
            info['originaltitle'] = parent_info['clip__special_name'] if parent_info['clip__special_name'] != '' else parent_info['clip__name']
#            title_atl_list = ['%s.' % (video['clip__set_name'])]
            title_atl_list = ['%s.' % (info['originaltitle'] if info['originaltitle'] != '' else video['clip__set_name'])]
            title_atl_list.append('s%02d' % (video['clip__season_number'] if video['clip__season_number'] != '' else 1))
            title_atl_list.append('e%02d' % (video['clip__position']))
            if video['clip__name'] != '':
                title_atl_list.append('.%s' % video['clip__name'])

            for title_part in title_atl_list:
                title_atl = title_atl + title_part

            if video['clip__name'] != '':
                title = '%02d. %s' % (video['clip__position'], video['clip__name'])
            else:
                title = '%s. %s %d' % (video['clip__set_name'], 'Серия'.decode('utf-8'), video['clip__position'])

            label = title
            #info['title'] = title
            info['tvshowtitle'] = video['clip__set_name']
            info['episode'] = video['clip__position']
            info['season'] = video['clip__season_number']

        elif video['clip__type_id'] == 5: #season
            clip_id = video['clip__id']
            parent_id = video['clip__id']
            label = '%s. %s' % (video['season__name'], video['clip__set_name'])

            title = video['season__name']

        #genre
        genres = video.get('genres')
        if genres != None:
            genre = ''
            for _genre in genres:
                genre =  '%s, %s' % (genre, _genre['mark__name'])
            info['genre'] = genre[2:]

        #year
        years = video.get('years')
        if years != None:
            year = years[0]['mark__name']
            info['year'] = int(year)
            if video['clip__type_id'] != 3:
                label = '%s (%s)' % (label, year)

        #rating
        ratingSourse = self.get_setting('rate_sourse')
        if ratingSourse == '1':   #kp
            info['rating'] = video['clip__kp_rate']
        elif ratingSourse == '2': #imdb
            info['rating'] = video['clip__imdb_rate']
        else:                   #tvzavr
            if video['clip__rates'] == 0:
                info['rating'] = video['clip__rating'] * 2
            else:
                info['rating'] = round(float(video['clip__ratesum']) * 2 / float(video['clip__rates']), 2)
            info['votes'] = video['clip__rates']

        info['plot']          = re.sub(r'\<[^>]*\>', '', video['clip__description'])
        info['duration']      = video['clip__duration'] * 60
        info['code']          = video['clip__imdb_id']

        if video['requires_subscription'] == 'Yes':
            subscription = ''
            tariffs = video.get('tariffs')
            if tariffs != None:
                tariffs_alias = {}
                for tariff in tariffs:
                    #subscription = '%s, %s' % (subscription, tariff['tariff__name'])
                    tariffs_alias[tariff['type_alias']] = True
                if tariffs_alias.get('purchase'):
                    subscription = '[COLOR=red][$][/COLOR]'
                if tariffs_alias.get('subscription'):
                    subscription = '[COLOR=green][$][/COLOR]'
                if subscription != '':
                    label = '[B]%s[/B] %s' % (subscription.decode('utf-8'), label)

        result = {}
        result['label'] = label
        result['title'] = title
        result['title_atl'] = title_atl if title_atl != '' else label
        result['clip_id']   = video['clip__id']
        result['season_id'] = video.get('season__id','')

        result['is_folder'] = True if video['clip__type_id'] not in [1, 3] else False

        vertical_clip = 'http://www.tvzavr.ru/cache/222x333/{0}.jpg'.format(clip_id)
        horisontal_clip = 'http://www.tvzavr.ru/cache/644x363/{0}.jpg'.format(clip_id)

        vertical_parent = 'http://www.tvzavr.ru/cache/222x333/{0}.jpg'.format(parent_id)
        horisontal_parent = 'http://www.tvzavr.ru/cache/644x363/{0}.jpg'.format(parent_id)

        if video['clip__type_id'] == 3: #episode
            arts = {'poster': vertical_parent,
                    'fanart': horisontal_parent,
                    'thumb': horisontal_clip}
        else:
            arts = {'poster': vertical_clip,
                    'fanart': horisontal_clip,
                    'thumb': horisontal_clip}

        result.update({'info': info, 'arts': arts})

        return result

    def get_catalog( self, params ):
        action = params['action']

        u_params = {}
        for param in params:
            if param[0] == '_':
                u_params[param[1:]] = params[param]

        u_params['limit'] = self.get_setting('limit')
        u_params['sort']  = self.get_setting('sort')
        u_params['plus']  = self.get_setting('plus')
        u_params['ff']    = self.get_setting('adult')

        return self.make_request(action, u_params)

    def get_seasons( self, clip_id ):

        u_params = {'plf':'and', 'cid': clip_id}
        return self.make_request('get_seasons', u_params)

    def get_series( self, season_id, limit ):

        u_params = {'plf':'and', 'cid': season_id, 'limit': limit}
        return self.make_request('get_series', u_params)

    def get_video_url( self, clip_id ):
        u_params = {'plf':'and', 'media':'apple', 'cid': clip_id}
        return self.make_request('get_video_url', u_params)

    def get_video_info( self, clip_id ):
        u_params = {'plf':'and', 'cid': clip_id}
        return self.make_request('get_video_info', u_params)

    def login( self ):
        email    = self.get_setting('email')
        password = self.get_setting('password')

        r_params = {'email': email, 'password': password, 'plf': 'and'}
        return self.make_request('login', r_params=r_params)

    def logout( self ):
        r_params = {'plf': 'and'}
        return self.make_request('logout', r_params=r_params)

    def get_playlist( self, response ):

        playlist_url = response['video']['url']
        if self.debug: xbmc.log( '[tvzavr]: playlist_url - %s ' % (playlist_url), 3 )

        #Получаем идентификатор сессии
        session_key = _get_session(playlist_url)
        if self.debug: xbmc.log( '[tvzavr]: session - %s' % (session_key), 3 )

        token = _generate_token(session_key, playlist_url)
        if self.debug: xbmc.log( '[tvzavr]: token - %s ' % (token), 3 )

        if self.get_setting('audio_lang') == 'rus':
            playlist_url = playlist_url.replace('mnf.m3u8', 'traudio_rus-trvideo-av-mnf.m3u8')

        playlist_key = {'usessionid': session_key, 'pageurl': 'null', 'token': token, 'platform': 'and'}
        playlist_content = _get_playlist_content(playlist_url, playlist_key)
        if playlist_content == None:
            return None

        video_quality = self.get_setting('video_quality')
        current_video_quality = 0

        if self.debug: xbmc.log( '[%s]: playlist_content - %s ' % (self.addon_id, playlist_content), 3 )

        variant_m3u8 = m3u8.M3U8(playlist_content, base_uri=_get_base_url(playlist_url))
        for playlist in variant_m3u8.playlists:
            resolution = playlist.stream_info.resolution
            if self.debug: xbmc.log( '[tvzavr]: resolution - %s , video_quality = %s, current_video_quality = %s' % (str(resolution), str(video_quality), str(current_video_quality)), 3 )
            if resolution != None and (video_quality == None or resolution[0] <= video_quality and resolution[0] >= current_video_quality):
                playlist_url = playlist.base_uri + playlist.uri
                current_video_quality = resolution[0]


        #playlist_url = '%s?%s' % (playlist_url, urlencode(playlist_key))
        if self.debug: xbmc.log( '[tvzavr]: playlist_url - %s ' % (playlist_url), 3 )
        return playlist_url

def _get_playlist_content(playlist_url, u_params):
    try:
        headers = {'User-Agent':'TZPlayer/3.5.12 (Linux;Android 5.1) ExoPlayerLib/1.5.8'}
        r = requests.get(playlist_url, params=u_params, headers=headers)
        r.raise_for_status()
        return r.text

    except requests.exceptions.RequestException as err:
        show_error('Error', str(err))
        return None

def _get_session( playlist_url ):
    s = urlparse.urlsplit(playlist_url)
    session_url = '%s://%s/session' % (s.scheme, s.netloc)
    headers = {'User-Agent':'okhttp/3.2.0'}
    r = requests.get(session_url, headers=headers)
    return r.text

def _generate_random32_string():
    result = ''
    charsets = '0123456789abcdef'
    while(len(result) < 32):
        index = int(math.floor(random.random() * 15))
        result = result + charsets[index]
    return result

def _generate_token( session_key, playlist_url):
    platform_secret = '65640f9590779991cf830f8eb6e7148c16edfa88c942302a6251380ee81697d4'
    random32 = _generate_random32_string()
    return _generate_SHA256_hash(session_key + playlist_url + random32 + 'null' + platform_secret);

def _generate_SHA256_hash( param ):
    return hashlib.sha256(param).hexdigest()

def _get_base_url(url):
    parsed_url = urlparse.urlsplit(url)
    prefix = '%s://%s' % (parsed_url.scheme, parsed_url.netloc)
    base_path = posixpath.normpath(parsed_url.path + '/..')
    return urlparse.urljoin(prefix, base_path)